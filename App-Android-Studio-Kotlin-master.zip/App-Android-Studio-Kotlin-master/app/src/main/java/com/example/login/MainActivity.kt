package com.example.login

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.View
import android.widget.EditText
import android.widget.Toast
import kotlin.reflect.typeOf

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun BotonClick(v : View){
        var edad=22
        Log.i("Titulo","mensaje info"+edad)
        Log.e("Titulo","mensaje info"+edad)
        Log.w("Titulo","mensaje info"+edad)
        Log.d("Titulo","mensaje info"+edad)

        val user= findViewById<EditText>(R.id.m_user)
        val pass=findViewById<EditText>(R.id.m_pass)
        val textuser=user.text.toString()
        val textpass=pass.text.toString()

        Toast.makeText(this@MainActivity,"el usuario"+user.text,Toast.LENGTH_LONG)

        if (textuser.equals("charly")and textpass.equals("123")){
            Toast.makeText(this,"el mensaje"+user.text,Toast.LENGTH_SHORT).show()
            val miintento=Intent(this.applicationContext,MainActivity2::class.java).apply { putExtra("user",textuser) }
            startActivity(miintento)
        }
        Toast.makeText(this,"el usuario es :"+user.text,Toast.LENGTH_LONG).show()

    }
}