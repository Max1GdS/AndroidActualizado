package com.example.login

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        val titulo=findViewById<TextView>(R.id.main2_titulo)
        val intent=getIntent()
        val mensaje="Bienvenido "+(intent.extras?.getString("user")?:intent.getStringExtra("user"))
        titulo.text=mensaje
    }

}